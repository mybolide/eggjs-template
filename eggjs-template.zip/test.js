fetch('http://localhost:7001/test', {
  method: 'POST',
  body: JSON.stringify({
    name: 'test',
  }),
}).then(res => {
  console.log(res);
});