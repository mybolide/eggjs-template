const fs = require('fs');
const path = require('path');
const parseRouterComments = require('./lib/autoRouter');

module.exports = app => {
  app.beforeStart(() => {
    const controllerDir = path.join(app.baseDir, 'app/controller');
    const files = fs.readdirSync(controllerDir);

    files.forEach(file => {
      const filePath = path.join(controllerDir, file);
      const routes = parseRouterComments(filePath);
      const ctrlName = path.basename(file, '.js');
      routes.forEach(r => {
        if (!app.controller[ctrlName] || !app.controller[ctrlName][r.methodName]) {
          app.logger.warn(`[AutoRouter] Controller ${ctrlName}.${r.methodName} not found`);
          return;
        }
        app.router[r.router.method](r.router.path, app.controller[ctrlName][r.methodName]);
        app.logger.info(`[AutoRouter] ${r.router.method.toUpperCase()} ${r.router.path} -> ${ctrlName}.${r.methodName}`);
      });
    });
  });
};
