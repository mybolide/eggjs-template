'use strict';
module.exports = {
    msg: {type: 'string',  required: false, description:'消息' }
};
